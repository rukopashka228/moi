<?php
// Запускаем сессию, чтобы можно было выводить сообщения об ошибках
session_start();
?>

<!-- Блок для вывода сообщений об ошибках или успехе -->
<?php if (isset($_SESSION['error_message'])): ?>
    <div class="alert alert-error">
        <?php
        echo $_SESSION['error_message'];
        // Удаляем сообщение после показа, чтобы оно не висело при обновлении
        unset($_SESSION['error_message']);
        ?>
    </div>
<?php endif; ?>

<?php if (isset($_GET['message'])): ?>
    <div class="alert alert-success">
        <?php echo htmlspecialchars($_GET['message']); ?>
    </div>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Логин</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
  <div class="container">

    <div class="title"><h2>Вход</h2></div>

        <div class="container">
          <div class="row align-items-center">
            <form class="needs-validation" novalidate action="vendor/signin.php" method="POST">

              <div class="col-md-3 align-items-center">
                <label for="validationCustom03" class="form-label">Логин</label>
                <input name="login" type="text" class="form-control" id="validationCustom03" required>
                <div class="invalid-feedback">
                    Введите логин.
                </div>
              </div>

              <div class="col-md-3">
                <label for="validationCustom05" class="form-label">Пароль</label>
                <input name="password" type="password" class="form-control" id="validationCustom05" required>
                <div class="invalid-feedback">
                  Введите пароль.
                </div>
              </div>

              <div class="col">
                <button class="btn btn-primary" type="submit">Войти</button>
              </div>

              <p>Нет аккаунта? <a href="register.php">Зарегистрируйтесь</a>.</p>
            </form>
          </div>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>

<?php
// Проверяем, что пользователь админ
require_once 'vendor/admin_check.php';

// Подключаемся к БД
require_once 'vendor/connect.php';

// Обработка действий (подтверждение, отмена, выполнение)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $order_id = (int)$_POST['order_id'];
    
    try {
        switch ($_POST['action']) {
            case 'confirm':
                $stmt = $pdo->prepare("UPDATE orders SET status = 'confirmed' WHERE id = ?");
                $stmt->execute([$order_id]);
                $_SESSION['admin_message'] = "Заявка #$order_id подтверждена";
                break;
                
            case 'complete':
                $stmt = $pdo->prepare("UPDATE orders SET status = 'done' WHERE id = ?");
                $stmt->execute([$order_id]);
                $_SESSION['admin_message'] = "Заявка #$order_id отмечена как выполненная";
                break;
                
            case 'cancel':
                if (empty($_POST['cancellation_reason'])) {
                    $_SESSION['admin_error'] = "Укажите причину отмены";
                } else {
                    $reason = trim($_POST['cancellation_reason']);
                    $stmt = $pdo->prepare("UPDATE orders SET status = 'cancelled', cancellation_reason = ? WHERE id = ?");
                    $stmt->execute([$reason, $order_id]);
                    $_SESSION['admin_message'] = "Заявка #$order_id отменена";
                }
                break;
        }
        
        // Перенаправляем на эту же страницу чтобы избежать повторной отправки формы
        header('Location: admin_panel.php');
        exit();
        
    } catch (PDOException $e) {
        die("Ошибка при обновлении заявки: " . $e->getMessage());
    }
}

// Получаем ВСЕ заявки из БД с информацией о пользователях
try {
    $sql = "SELECT 
                o.*, 
                u.full_name, 
                u.login,
                u.email,
                u.phone as user_phone,
                s.name as service_name 
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            LEFT JOIN services s ON o.service_id = s.id 
            ORDER BY o.created_at DESC";
    
    $stmt = $pdo->query($sql);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    die("Ошибка при загрузке заявок: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="admin-container">
            <div class="admin-header">
                <h1>Панель администратора</h1>
                <div class="btn btn-primary"><a href="vendor/logout.php" style="text-decoration: none; color: #FFFFFF;">Выход</a></div>
                <div class="admin-stats">
                    <span>Всего заявок: <strong><?php echo count($orders); ?></strong></span>
                    <span>Новых: <strong><?php echo count(array_filter($orders, fn($o) => $o['status'] == 'new')); ?></strong></span>
                </div>
            </div>

            <!-- Сообщения об успехе/ошибке -->
            <?php if (isset($_SESSION['admin_message'])): ?>
                <div class="alert alert-success">
                    <?php echo $_SESSION['admin_message']; ?>
                    <?php unset($_SESSION['admin_message']); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['admin_error'])): ?>
                <div class="alert alert-error">
                    <?php echo $_SESSION['admin_error']; ?>
                    <?php unset($_SESSION['admin_error']); ?>
                </div>
            <?php endif; ?>

            <div class="admin-filters">
                <button class="filter-btn active btn btn-primary" data-filter="all">Все</button>
                <button class="filter-btn btn btn-primary" data-filter="new">Новые</button>
                <button class="filter-btn btn btn-primary" data-filter="confirmed">Подтвержденные</button>
                <button class="filter-btn btn btn-primary" data-filter="done">Выполненные</button>
                <button class="filter-btn btn btn-primary" data-filter="cancelled">Отмененные</button>
            </div>

            <div class="orders-list">
                <?php if (empty($orders)): ?>
                    <div class="empty-state">
                        <p>Заявок пока нет</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <div class="order-card order-status-<?php echo $order['status']; ?>" data-status="<?php echo $order['status']; ?>">
                            <div class="order-header">
                                <div>
                                    <h3>Заявка #<?php echo $order['id']; ?></h3>
                                    <small>Создана: <?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></small>
                                </div>
                                <span class="status-badge status-<?php echo $order['status']; ?>">
                                    <?php 
                                    $statuses = [
                                        'new' => '🆕 Новая',
                                        'confirmed' => '✅ Подтверждена',
                                        'done' => '✔️ Выполнена', 
                                        'cancelled' => '❌ Отменена'
                                    ];
                                    echo $statuses[$order['status']] ?? $order['status'];
                                    ?>
                                </span>
                            </div>

                            <div class="order-details">
                                <div class="detail-section">
                                    <h4>Информация о клиенте</h4>
                                    <div class="detail-grid">
                                        <div class="detail-item">
                                            <span class="label">ФИО:</span>
                                            <span class="value"><?php echo htmlspecialchars($order['full_name']); ?></span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="label">Логин:</span>
                                            <span class="value"><?php echo htmlspecialchars($order['login']); ?></span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="label">Email:</span>
                                            <span class="value"><?php echo htmlspecialchars($order['email']); ?></span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="label">Телефон клиента:</span>
                                            <span class="value"><?php echo htmlspecialchars($order['user_phone']); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="detail-section">
                                    <h4>Детали заявки</h4>
                                    <div class="detail-grid">
                                        <div class="detail-item">
                                            <span class="label">Адрес уборки:</span>
                                            <span class="value"><?php echo htmlspecialchars($order['address']); ?></span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="label">Контактный телефон:</span>
                                            <span class="value"><?php echo htmlspecialchars($order['phone']); ?></span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="label">Услуга:</span>
                                            <span class="value">
                                                <?php if ($order['service_id']): ?>
                                                    <?php echo htmlspecialchars($order['service_name']); ?>
                                                <?php else: ?>
                                                    <?php echo htmlspecialchars($order['custom_service']); ?> (другая услуга)
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="label">Дата/время:</span>
                                            <span class="value">
                                                <?php echo date('d.m.Y', strtotime($order['desired_date'])); ?> 
                                                в <?php echo $order['desired_time']; ?>
                                            </span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="label">Способ оплаты:</span>
                                            <span class="value">
                                                <?php echo $order['payment_type'] == 'cash' ? 'Наличные' : 'Банковская карта'; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <?php if ($order['status'] == 'cancelled' && !empty($order['cancellation_reason'])): ?>
                                <div class="detail-section">
                                    <h4>Причина отмены</h4>
                                    <p class="cancellation-reason"><?php echo htmlspecialchars($order['cancellation_reason']); ?></p>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="admin-actions">
                                <?php if ($order['status'] == 'new'): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                        <input type="hidden" name="action" value="confirm">
                                        <button type="submit" class="btn btn-success">Подтвердить</button>
                                    </form>
                                    
                                    <button type="button" class="btn btn-danger" onclick="showCancelForm(<?php echo $order['id']; ?>)">Отклонить</button>
                                    
                                    <!-- Форма для отказа (изначально скрыта) -->
                                    <form method="POST" id="cancel-form-<?php echo $order['id']; ?>" class="cancel-form" style="display: none;">
                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                        <input type="hidden" name="action" value="cancel">
                                        <textarea name="cancellation_reason" placeholder="Укажите причину отмены" required rows="2"></textarea>
                                        <div class="cancel-buttons">
                                            <button type="submit" class="btn btn-warning">Подтвердить отмену</button>
                                            <button type="button" class="btn" onclick="hideCancelForm(<?php echo $order['id']; ?>)">Отмена</button>
                                        </div>
                                    </form>
                                    
                                <?php elseif ($order['status'] == 'confirmed'): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                        <input type="hidden" name="action" value="complete">
                                        <button type="submit" class="btn btn-primary">Отметить выполненной</button>
                                    </form>
                                <?php elseif ($order['status'] == 'done'): ?>
                                    <span class="completed-text">✅ Заявка выполнена</span>
                                <?php elseif ($order['status'] == 'cancelled'): ?>
                                    <span class="cancelled-text">❌ Заявка отменена</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <script>
        // Функции для формы отмены
        function showCancelForm(orderId) {
            document.getElementById('cancel-form-' + orderId).style.display = 'block';
        }

        function hideCancelForm(orderId) {
            document.getElementById('cancel-form-' + orderId).style.display = 'none';
        }

        // Фильтрация заявок
        document.addEventListener('DOMContentLoaded', function() {
            const filterButtons = document.querySelectorAll('.filter-btn');
            const orderCards = document.querySelectorAll('.order-card');
            
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const filter = this.getAttribute('data-filter');
                    
                    // Активный класс кнопки
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Фильтрация карточек
                    orderCards.forEach(card => {
                        if (filter === 'all' || card.getAttribute('data-status') === filter) {
                            card.style.display = 'block';
                        } else {
                            card.style.display = 'none';
                        }
                    });
                });
            });
        });
        </script>
    </div>
</body>
</html>

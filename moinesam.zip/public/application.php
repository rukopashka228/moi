<?php
// Запускаем сессию и проверяем авторизацию
require_once 'vendor/auth_check.php';

// Подключаемся к БД
require_once 'vendor/connect.php';

// Получаем ВСЕ заявки текущего пользователя
try {
    $sql = "SELECT 
                o.*, 
                s.name as service_name 
            FROM orders o 
            LEFT JOIN services s ON o.service_id = s.id 
            WHERE o.user_id = ? 
            ORDER BY o.created_at DESC"; // Сначала новые заявки
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_SESSION['user_id']]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    die("Ошибка при загрузке заявок: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <h1>Мои заявки</h1>
            <a href="index.php" class="btn btn-primary">+ Новая заявка</a>
        </div>

        <?php if (empty($orders)): ?>
            <div class="empty-state">
                <p>У вас пока нет созданных заявок.</p>
                <a href="index.php" class="btn">Создать первую заявку</a>
            </div>
        <?php else: ?>
            <div class="orders-container">
                <div class="orders-stats">
                    <p>Всего заявок: <strong><?php echo count($orders); ?></strong></p>
                </div>

                <div class="orders-list">
                    <?php foreach ($orders as $order): ?>
                        <div class="order-card order-status-<?php echo $order['status']; ?>">
                            <div class="order-header">
                                <h3>Заявка #<?php echo $order['id']; ?></h3>
                                <span class="status-badge status-<?php echo $order['status']; ?>">
                                    <?php 
                                    // Красивые названия статусов
                                    $statuses = [
                                        'new' => '🆕 Новая',
                                        'confirmed' => '✅ Подтверждена',
                                        'done' => '✔️ Выполнена', 
                                        'cancelled' => '❌ Отменена'
                                    ];
                                    echo $statuses[$order['status']] ?? $order['status'];
                                    ?>
                                </span>
                            </div>

                            <div class="order-details">
                                <div class="detail-row">
                                    <span class="label">Дата создания:</span>
                                    <span class="value"><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></span>
                                </div>
                                
                                <div class="detail-row">
                                    <span class="label">Адрес уборки:</span>
                                    <span class="value"><?php echo htmlspecialchars($order['address']); ?></span>
                                </div>
                                
                                <div class="detail-row">
                                    <span class="label">Контактный телефон:</span>
                                    <span class="value"><?php echo htmlspecialchars($order['phone']); ?></span>
                                </div>
                                
                                <div class="detail-row">
                                    <span class="label">Услуга:</span>
                                    <span class="value">
                                        <?php if ($order['service_id']): ?>
                                            <?php echo htmlspecialchars($order['service_name']); ?>
                                        <?php else: ?>
                                            <?php echo htmlspecialchars($order['custom_service']); ?> (другая услуга)
                                        <?php endif; ?>
                                    </span>
                                </div>
                                
                                <div class="detail-row">
                                    <span class="label">Желаемые дата и время:</span>
                                    <span class="value">
                                        <?php echo date('d.m.Y', strtotime($order['desired_date'])); ?> 
                                        в <?php echo $order['desired_time']; ?>
                                    </span>
                                </div>
                                
                                <div class="detail-row">
                                    <span class="label">Способ оплаты:</span>
                                    <span class="value">
                                        <?php echo $order['payment_type'] == 'cash' ? 'Наличные' : 'Банковская карта'; ?>
                                    </span>
                                </div>
                                
                                <?php if ($order['status'] == 'cancelled' && !empty($order['cancellation_reason'])): ?>
                                <div class="detail-row">
                                    <span class="label">Причина отмены:</span>
                                    <span class="value" style="color: #d32f2f;">
                                        <?php echo htmlspecialchars($order['cancellation_reason']); ?>
                                    </span>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($order['status'] == 'new'): ?>
                            <div class="order-actions">
                                <small>Заявка на рассмотрении администратором</small>
                            </div>
                            <?php elseif ($order['status'] == 'confirmed'): ?>
                            <div class="order-actions">
                                <small>✅ Заявка подтверждена, ожидайте исполнителя</small>
                            </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
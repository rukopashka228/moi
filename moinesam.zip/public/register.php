<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div class="container">

    <h2>Регистрация</h2>
        <form class="row g-3 needs-validation" novalidate action="vendor/signup.php" method="POST">
          <div class="col-md-4">
            <label for="validationCustom01" class="form-label">Ф.И.О</label>
            <input name="full_name" type="text" class="form-control" id="validationCustom01" placeholder="Иванов Иван Иванович" required>
            <div class="valid-feedback">
              Looks good!
            </div>
          </div>

          <div class="col-md-4">
            <label for="validationCustom02" class="form-label">Номер телефона</label>
            <input name="phone" type="tel" class="form-control" id="validationCustom02" placeholder="+7-(999)-888-77-66" required>
            <div class="valid-feedback">
              Looks good!
            </div>
          </div>

          <div class="col-md-4">
            <label for="validationCustomUsername" class="form-label">Эл.Почта</label>
            <div class="input-group">
              <span class="input-group-text" id="inputGroupPrepend">@</span>
              <input name="email" type="email" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
              <div class="invalid-feedback">
                Введите Эл.Почту.
              </div>
            </div>
          </div>

          <div class="col-md-3">
            <label for="validationCustom03" class="form-label">Логин</label>
            <input name="login" type="text" class="form-control" id="validationCustom03" required>
            <div class="invalid-feedback">
                Придумайте логин.
            </div>
          </div>

          <div class="col-md-3">
            <label for="validationCustom05" class="form-label">Пароль</label>
            <input name="password" type="password" class="form-control" id="validationCustom05" required>
            <div class="invalid-feedback">
              Придумайте пароль.
            </div>
          </div>

          <div class="col-12">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
              <label class="form-check-label" for="invalidCheck">
                Agree to terms and conditions
              </label>
              <div class="invalid-feedback">
                You must agree before submitting.
              </div>
            </div>
          </div>

          <div class="col-12">
            <button class="btn btn-primary" type="submit">Зарегестрироваться</button>
          </div>
          <p>Уже есть аккаунт? <a href="login.php">Войти</a>.</p>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
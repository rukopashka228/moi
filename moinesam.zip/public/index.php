<?php
require_once 'vendor/auth_check.php';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container-fluid">
        <h2>Добро пожаловать, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h2>
        <p>Это ваш личный кабинет. Здесь вы можете создать заявку.</p>

        <div class="row g-2">
            <div class="orders col-1">
                <a href="application.php" class="btn btn-primary p-2">Мои заявки</a>
            </div>
            <div class="profile-menu col-1">
                <a href=" /vendor/logout.php" class="btn btn-primary p-2">Выйти</a>
            </div>    
        </div>



        <h2>Создание новой заявки</h2>

        <!-- Блок для вывода сообщений об ошибках из сессии -->
        <?php if (isset($_SESSION['order_errors']) && !empty($_SESSION['order_errors'])): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($_SESSION['order_errors'] as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php unset($_SESSION['order_errors']); // Очищаем ошибки после показа ?>
        <?php endif; ?>

        <!-- Сообщение об успехе -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                Заявка успешно создана!
            </div>
        <?php endif; ?>

        <form action="/vendor/request.php" method="POST" id="orderForm">
        <div class="row g-5">
            <div class="col-2">
                <!-- Адрес -->
                <label for="address">Адрес уборки:*</label>
                <textarea id="address" name="address" rows="3" required placeholder="Укажите полный адрес"></textarea>
            </div>

            <div class="col-2">
                <!-- Контактный телефон -->
                <label for="phone">Контактный телефон:*</label>
                <input type="tel" id="phone" name="phone" required 
                    value="<?php echo isset($_SESSION['phone']) ? htmlspecialchars($_SESSION['phone']) : ''; ?>"
                    placeholder="+7(XXX)-XXX-XX-XX">
            </div>

            <div class="col-2">
                <!-- Желаемая дата -->
                <label for="desired_date">Желаемая дата:*</label>
                <input type="date" id="desired_date" name="desired_date" required 
                    min="<?php echo date('Y-m-d'); // Минимальная дата - сегодня ?>">
            </div>

            <div class="col-3">
                <!-- Желаемое время -->
                <label for="desired_time">Желаемое время:*</label>
                <input type="time" id="desired_time" name="desired_time" required min="09:00" max="21:00">
            </div>

            <div class="col-4">
                <!-- Выбор услуги -->
                <label>Вид услуги:*</label>
                <?php
                // Подключаемся к БД чтобы получить список услуг
                require_once 'vendor/connect.php';
                try {
                    $sql = "SELECT id, name FROM services";
                    $stmt = $pdo->query($sql);
                    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    die("Ошибка при загрузке услуг: " . $e->getMessage());
                }
                ?>

                <?php foreach ($services as $service): ?>
                    <div class="radio-group">
                        <input class="form-check-input" type="radio" id="service_<?php echo $service['id']; ?>" name="service_id" 
                            value="<?php echo $service['id']; ?>" required>
                        <label for="service_<?php echo $service['id']; ?>"><?php echo htmlspecialchars($service['name']); ?></label>
                    </div>
                <?php endforeach; ?>

                <!-- Чекбокс для другой услуги -->
                <div class="radio-group">
                    <input class="form-check-input" type="radio" id="service_other" name="service_id" value="other">
                    <label for="service_other">Иная услуга</label>
                </div>

                <!-- Поле для своей услуги (изначально скрыто) -->
                <div id="custom_service_container" style="display: none;">
                    <label for="custom_service">Опишите вашу услугу:*</label>
                    <textarea id="custom_service" name="custom_service" rows="3" 
                            placeholder="Подробно опишите, что нужно сделать"></textarea>
                </div>
            </div>

            <div class="col-4">
                <!-- Тип оплаты -->
                <label>Предпочтительный тип оплаты:*</label>
                <div class="radio-group">
                    <input class="form-check-input" type="radio" id="payment_cash" name="payment_type" value="cash" required>
                    <label for="payment_cash">Наличные</label>
                </div>
                <div class="radio-group">
                    <input class="form-check-input" type="radio" id="payment_card" name="payment_type" value="card" required>
                    <label for="payment_card">Банковская карта</label>
                </div>
            </div>


            <button class="btn btn-primary col-md-6" type="submit">Отправить заявку</button>
        </div>
        </form>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <!-- JavaScript для переключения поля "Иная услуга" -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const otherRadio = document.getElementById('service_other');
            const customContainer = document.getElementById('custom_service_container');
            const customTextarea = document.getElementById('custom_service');
            
            // Обработчик изменения выбора услуги
            document.querySelectorAll('input[name="service_id"]').forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.value === 'other') {
                        customContainer.style.display = 'block';
                        customTextarea.setAttribute('required', 'required');
                    } else {
                        customContainer.style.display = 'none';
                        customTextarea.removeAttribute('required');
                        customTextarea.value = '';
                    }
                });
            });
        });
        </script>
    </div>
</body>
</html>